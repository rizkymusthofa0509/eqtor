import 'package:eqtor/utils/drawer.dart';
import 'package:eqtor/utils/screen_config.dart';
import 'package:eqtor/views/v_account.dart';
import 'package:eqtor/views/v_graffic.dart';
import 'package:eqtor/views/v_home.dart';
import 'package:eqtor/views/v_information.dart';
import 'package:eqtor/views/v_news.dart';
import 'package:flutter/material.dart';
import 'package:bmnav/bmnav.dart' as bmnav;

class ViewIndex extends StatefulWidget {
  @override
  _ViewIndexState createState() => _ViewIndexState();
}

class _ViewIndexState extends State<ViewIndex> {
  int currentTab = 0;
  var title="Home";
  final List<Widget> screens = [
    ViewHome(),
    ViewInformation(),
    ViewNews(),
    ViewGrahp(),
  ];
  Widget currentScreen = ViewHome();

  final PageStorageBucket bucket = PageStorageBucket();
  @override
  Widget build(BuildContext context) {
    ScreenConfig().init(context);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: Text(title,style: TextStyle(color: Colors.white),),
        centerTitle: true,
        actions: [
          InkWell(
            onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>ViewAccount())),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Icon(
                Icons.account_circle,
                size: ScreenConfig.blockHorizontal * 10,
                color: Colors.white,
              ),
            ),
          ),
        ],
      ),
//      drawer: drawer(context: context),
      body: PageStorage(child: currentScreen, bucket: bucket),
      bottomNavigationBar: bmnav.BottomNav(
        index: currentTab,
        iconStyle: bmnav.IconStyle(),
        labelStyle: bmnav.LabelStyle(visible: false),
        onTap: (i) {
          setState(() {
            currentTab = i;
            print(i);

            currentScreen = screens[i];
            if(i==0){
              title="Home";
            }else if(i==1){
              title="Informasi";
            }else if(i==2){
              title="News";
            }else if(i==3){
              title="Graphic";
            }
          });
        },
        items: [
          bmnav.BottomNavItem(Icons.home,),
          bmnav.BottomNavItem(Icons.info),
          bmnav.BottomNavItem(Icons.chrome_reader_mode),
          bmnav.BottomNavItem(Icons.score)
        ],
      ),
    );
  }
}
